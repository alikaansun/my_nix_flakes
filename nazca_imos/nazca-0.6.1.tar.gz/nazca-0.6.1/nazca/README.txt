For the nazca modules to be found it has to be set in the PTYHONPATH environment variable
export PYTHONPATH=<path>

where <path> has to be with the path to the directory containing the module directory nazca.
Hence the module resides in <path>0/nazca

On Linux in a bash shell (in ~./bash_rc):
export PYTHONPATH=$PYTHONPATH:<path>

Be sure to set the PYTHONPATH before launching the py script editor.




